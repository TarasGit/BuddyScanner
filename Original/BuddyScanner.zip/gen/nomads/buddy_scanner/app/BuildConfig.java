/** Automatically generated file. DO NOT MODIFY */
package nomads.buddy_scanner.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}