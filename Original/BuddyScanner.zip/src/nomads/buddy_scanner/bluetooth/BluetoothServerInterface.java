package nomads.buddy_scanner.bluetooth;

public interface BluetoothServerInterface {
	
	
}
